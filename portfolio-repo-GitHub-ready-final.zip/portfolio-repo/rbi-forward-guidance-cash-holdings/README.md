# RBI Forward Guidance & Corporate Precautionary Cash Holdings

An applied financial-econometrics research project studying whether **RBI forward guidance** is associated with firms' precautionary cash holdings. The project is deliberately complementary to the predictive models in the portfolio: the focus here is on empirical design, inference, robustness, and economic interpretation.

## Research question

Does the way monetary policy communicates its future path relate to how much cash firms hold, after accounting for firm characteristics and macroeconomic conditions?

## Empirical design

- Firm-year panel with **entity fixed effects** using `linearmodels.PanelOLS`
- Dependent variable: winsorized `CashRatio`
- Main explanatory variable: `PathFactor`, an RBI forward-guidance measure
- Alternative monetary-policy measure: `TargetFactor`
- Firm controls include size, leverage, cash flow, sales growth, tangibility, dividends, working capital, age, and interest coverage
- Macro controls include GDP growth, CPI inflation, Economic Policy Uncertainty, VIX, and the Fed Funds Rate
- Standard errors are clustered by firm; alternative inference includes wild cluster bootstrap
- VIF diagnostics assess multicollinearity
- Placebo/lead specifications test whether future forward guidance predicts current cash holdings

## Research workflow

**Data construction → baseline fixed effects → inference robustness → alternative mechanisms → placebo/lead tests → financial-market and balance-sheet extensions**

The notebook contains exploratory and robustness specifications. The final interpretation should distinguish the baseline association from additional mechanism tests and should not treat fixed-effects estimates as automatic causal identification.

## Key skills

**Panel econometrics · Fixed effects · Clustered inference · Wild bootstrap · Robustness testing · Financial analysis · Python**

## Notebook

`panel_regression_analysis.ipynb` — data preparation, winsorization, panel construction, fixed-effects regressions, robustness checks, and placebo/lead tests.

The underlying research datasets are not included in this repository.
