# Applied Data Science, Credit Risk & Financial Econometrics

A focused portfolio of three applied research projects spanning **machine learning, credit-risk modeling, SQL, and financial econometrics**.

The projects are intentionally complementary: they move from **prediction → risk modeling → economic reasoning**, with an emphasis on temporal validation, leakage control, probability calibration, interpretable models, and robust inference.

## Projects

### 1. FinGuard AI — Corporate Distress Prediction
**Question:** Can firm-level financial information identify current and future corporate distress?

**Methods:** Logistic Regression · Random Forest · XGBoost · SHAP · temporal out-of-time evaluation

**Highlights:**
- 25,296 firm-year observations from 2,108 NSE mainboard non-financial firms
- Explicit target/leakage audit, including exclusion of ICR from predictors because it contributes to target construction
- Chronological train/validation/OOT design
- Class-aware evaluation using balanced accuracy, Macro F1, ROC-AUC, and class-level recall
- Separate one-year-ahead early-warning experiment

**Canonical OOT result:** 94.66% accuracy · 89.53% balanced accuracy · 0.890 Macro F1 · 0.987 ROC-AUC

→ **[Open project](./finguard-ai-distress-prediction/)**

---

### 2. Freddie Mac Mortgage PD Model
**Question:** Can loan-level origination information be converted into a useful 36-month probability-of-default model that generalizes to a later mortgage vintage?

**Methods:** SQL/SQLite · Logistic Regression · XGBoost · probability calibration · temporal/OOT validation

**Highlights:**
- Loan-level default-target construction with 36-month seasoning
- SQL joins, aggregations, and window functions for feature engineering
- Pipeline-based preprocessing and model comparison
- Probability calibration rather than relying only on ranking metrics
- 2022 out-of-time evaluation under changing interest-rate conditions

**Key result:** ROC-AUC falls from 0.8118 in-sample to 0.683 OOT, demonstrating meaningful temporal/model-regime deterioration rather than hiding it behind an in-sample score.

→ **[Open project](./freddie-mac-mortgage-pd-model/)**

---

### 3. RBI Forward Guidance & Corporate Precautionary Cash Holdings
**Question:** How is monetary-policy communication associated with firms' precautionary cash holdings?

**Methods:** Panel Fixed Effects · clustered inference · wild cluster bootstrap · placebo/lead tests · multicollinearity diagnostics

**Highlights:**
- Firm-year panel with entity fixed effects
- RBI forward-guidance and alternative monetary-policy measures
- Firm-level and macroeconomic controls
- Robust inference and alternative specifications
- Placebo/lead tests to probe timing and reduce over-interpretation

**Research stance:** The notebook distinguishes fixed-effects association from causal identification and treats robustness checks as evidence to evaluate—not as automatic proof of causality.

→ **[Open project](./rbi-forward-guidance-cash-holdings/)**

---

## What this portfolio demonstrates

Across the projects, the recurring focus is **methodological discipline**:

- **Leakage control** — targets and predictors are constructed so that future information is not accidentally used.
- **Temporal validation** — future-period performance is separated from random-split performance where appropriate.
- **Risk-aware evaluation** — class imbalance and probability quality are considered alongside headline accuracy.
- **Interpretability** — model behavior is examined using feature importance and SHAP rather than treating predictions as a black box.
- **Robust inference** — econometric results are tested across specifications, clustering choices, bootstrap inference, and placebo/lead designs.
- **Honest model assessment** — performance deterioration is reported when it occurs instead of being hidden by favorable splits.

## Repository structure

```text
portfolio-repo/
├── finguard-ai-distress-prediction/
│   ├── README.md
│   ├── requirements.txt
│   └── notebooks
├── freddie-mac-mortgage-pd-model/
│   ├── README.md
│   ├── requirements.txt
│   └── notebooks
├── rbi-forward-guidance-cash-holdings/
│   ├── README.md
│   ├── requirements.txt
│   └── notebook
├── requirements.txt
├── .gitignore
└── LICENSE
```

## Reproducibility & data

The repository contains the **analysis code, notebooks, methodology, and dependency files**. Raw/private/source datasets and generated databases are intentionally excluded.

Before running a project:

1. Read its project-level `README.md`.
2. Obtain the permitted source data separately.
3. Place the required files under that project's `./data/` directory using the paths expected by the notebooks.
4. Install the corresponding project-level `requirements.txt` (or use the root requirements file for the combined environment).
5. Run the notebooks in their listed order.

The notebooks use project-relative paths rather than machine-specific absolute paths. Generated data, databases, figures, caches, environments, and archives are excluded by `.gitignore`.

> **Note:** Notebook outputs are intentionally kept lightweight/cleared in this repository. The reported results in the project READMEs describe the stated final specifications and should be interpreted together with their target definitions and temporal splits.

## Important interpretation note

These projects are portfolio research exercises, not production credit models or causal policy evaluations. Results depend on the underlying data, target construction, sample period, modeling choices, and economic regime. The documentation is designed to make those assumptions visible rather than imply universal performance.
